~~~NOTICE~~~

Objects found within the RootObjects folder contain all of a given object's information: from Mesh, Material to Colliders, etc. 

~~~WARNING~~~

Adjusting these objects in any way will cause all versions of those objects to change and may break the associated prefabs or game.